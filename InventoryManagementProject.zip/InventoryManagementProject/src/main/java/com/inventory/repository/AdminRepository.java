package com.inventory.repository;



import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.inventory.data.Admin;

public interface AdminRepository extends JpaRepository<Admin, Integer>{

}

