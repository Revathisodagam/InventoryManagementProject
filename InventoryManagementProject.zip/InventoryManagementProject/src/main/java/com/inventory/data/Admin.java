package com.inventory.data;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table (name ="Admin")
public class Admin {
	@Id
     int userid;
     String password;
 
     Admin() {}
     

	public Admin(int userid, String password) {
		super();
		this.userid = userid;
		this.password = password;
	}


	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


	@Override
	public String toString() {
		return "Admin [userid=" + userid + ", password=" + password + "]";
	}
     
     
}
