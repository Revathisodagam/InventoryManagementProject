package com.inventory.data;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table (name ="Product")
public class Product {
	@Id
     int productId;
     String name;
     String description;
     double cost;
     int avlQty;
     int minQty;
     Product() {}
	public Product(int productId, String name, String description, double cost, int avlQty, int minQty) {
		super();
		this.productId = productId;
		this.name = name;
		this.description = description;
		this.cost = cost;
		this.avlQty = avlQty;
		this.minQty = minQty;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	public int getAvlQty() {
		return avlQty;
	}
	public void setAvlQty(int avlQty) {
		this.avlQty = avlQty;
	}
	public int getMinQty() {
		return minQty;
	}
	public void setMinQty(int minQty) {
		this.minQty = minQty;
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", name=" + name + ", description=" + description + ", cost=" + cost
				+ ", avlQty=" + avlQty + ", minQty=" + minQty + "]";
	}

	
}