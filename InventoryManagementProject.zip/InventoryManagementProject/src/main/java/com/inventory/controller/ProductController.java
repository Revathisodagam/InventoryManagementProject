package com.inventory.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;

import com.inventory.data.Admin;
import com.inventory.data.Product;

import com.inventory.repository.ProductRepository;

@RestController //Spring REST
public class ProductController {


@Autowired 
  ProductRepository prodRepo;
	@GetMapping ("/getAllProducts")
	public List<Product> getAllProducts() {
		//SELECT * FROM PRODUCT;
		List<Product> productList= prodRepo.findAll();
		
	return productList;	
	}
	//POSTMapping-- To insert data in database.
	//http://localhost:8080/insertData
	
	@PostMapping ("/insertData")
	public String insertData(@RequestBody Product productObj) {
		System.out.println("Received data is : " +productObj);
	    prodRepo.save(productObj);
		return "Given data is inserted in the database successfully.....";
	}
	
	//http://localhost:8080/updateData
	@PutMapping ("/updateData")
	public String updateData(@RequestBody Product productObj) {
		System.out.println("Received data is : " +productObj);
	    prodRepo.save(productObj);
	    return "Given data is updated in the database successfully.....";
	}
	//http://localhost:8080/deleteData
	@DeleteMapping ("/deleteData/{productId}")
	public String deleteData(@PathVariable int productId) {
		System.out.println("Given ID to delete is : " +productId);
	    prodRepo.deleteById(productId);
	    return "Given data is deleted in the database successfully.....";
	}
}
